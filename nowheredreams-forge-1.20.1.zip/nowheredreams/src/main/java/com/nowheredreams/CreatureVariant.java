package com.nowheredreams;

import java.util.function.Supplier;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffects;

/** Las 7 criaturas, una por cada imagen. Nombres propios (no oficiales). */
public enum CreatureVariant {
    //          id               ancho alto  vida dmg  vel   efecto al golpear                  seg  brazosExtra huevo1    huevo2
    VEILED(     "veiled_one",    1.0f, 1.15f, 40,  6,  0.22, () -> MobEffects.BLINDNESS,         4,  false, 0x15101a, 0xc8967a),
    WHITE_CROWN("white_crowned", 1.0f, 1.10f, 35,  5,  0.25, () -> MobEffects.MOVEMENT_SLOWDOWN, 5,  false, 0xe6f0e6, 0x5a2823),
    STILT(      "stilt_walker",  0.8f, 1.60f, 30,  5,  0.30, () -> MobEffects.CONFUSION,        6,  false, 0xaa645a, 0x101010),
    RED_MAW(    "red_maw",       1.1f, 1.20f, 50,  9,  0.26, () -> MobEffects.WITHER,            3,  false, 0x0a0a0c, 0x961e23),
    MANY_ARMS(  "many_arms",     1.2f, 1.30f, 45,  7,  0.24, () -> MobEffects.DIG_SLOWDOWN,      5,  true,  0x1e191c, 0xc8beb9),
    CONE(       "cone_sitter",   0.9f, 0.95f, 30,  6,  0.34, () -> MobEffects.DARKNESS,          5,  false, 0x191619, 0x8c6e6e),
    BATH_GIANT( "bath_giant",    0.9f, 1.90f, 80, 10,  0.18, () -> MobEffects.LEVITATION,        2,  false, 0xebebeb, 0xa0a0a0);

    public final String id;
    public final float width, height;
    public final double health, damage, speed;
    public final Supplier<MobEffect> effect;
    public final int effectSeconds;
    public final boolean extraArms;
    public final int eggPrimary, eggSecondary;
    public final ResourceLocation texture;

    CreatureVariant(String id, float w, float h, double hp, double dmg, double speed,
                    Supplier<MobEffect> effect, int sec, boolean extraArms, int e1, int e2) {
        this.id = id; this.width = w; this.height = h;
        this.health = hp; this.damage = dmg; this.speed = speed;
        this.effect = effect; this.effectSeconds = sec; this.extraArms = extraArms;
        this.eggPrimary = e1; this.eggSecondary = e2;
        this.texture = new ResourceLocation("nowheredreams", "textures/entity/" + id + ".png");
    }
}
