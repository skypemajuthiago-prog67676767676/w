package com.nowheredreams.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.nowheredreams.DreamCreature;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class DreamCreatureRenderer extends MobRenderer<DreamCreature, DreamCreatureModel> {
    public DreamCreatureRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new DreamCreatureModel(ctx.bakeLayer(DreamCreatureModel.LAYER)), 0.4f);
    }

    @Override
    public ResourceLocation getTextureLocation(DreamCreature e) { return e.getVariant().texture; }

    @Override
    protected void scale(DreamCreature e, PoseStack ps, float partialTick) {
        ps.scale(e.getVariant().width, e.getVariant().height, e.getVariant().width);
    }
}
