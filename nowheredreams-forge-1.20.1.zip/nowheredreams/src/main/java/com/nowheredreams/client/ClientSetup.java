package com.nowheredreams.client;

import com.nowheredreams.CreatureVariant;
import com.nowheredreams.NowhereDreams;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = NowhereDreams.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {
    @SubscribeEvent
    public static void layers(EntityRenderersEvent.RegisterLayerDefinitions e) {
        e.registerLayerDefinition(DreamCreatureModel.LAYER, DreamCreatureModel::createBodyLayer);
    }

    @SubscribeEvent
    public static void renderers(EntityRenderersEvent.RegisterRenderers e) {
        for (CreatureVariant v : CreatureVariant.values())
            e.registerEntityRenderer(NowhereDreams.CREATURES.get(v).get(), DreamCreatureRenderer::new);
    }
}
