package com.nowheredreams.client;

import com.nowheredreams.DreamCreature;
import com.nowheredreams.NowhereDreams;
import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** Modelo humanoide delgado y alto, con 3 pares de brazos (los extra solo se ven en algunas criaturas). */
public class DreamCreatureModel extends HierarchicalModel<DreamCreature> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(NowhereDreams.MODID, "dream_creature"), "main");

    private final ModelPart root, head, body, rArm, lArm, rLeg, lLeg, rArm2, lArm2, rArm3, lArm3;

    public DreamCreatureModel(ModelPart root) {
        this.root = root;
        head = root.getChild("head");
        body = root.getChild("body");
        rArm = root.getChild("right_arm");
        lArm = root.getChild("left_arm");
        rLeg = root.getChild("right_leg");
        lLeg = root.getChild("left_leg");
        rArm2 = root.getChild("right_arm2");
        lArm2 = root.getChild("left_arm2");
        rArm3 = root.getChild("right_arm3");
        lArm3 = root.getChild("left_arm3");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition r = mesh.getRoot();
        r.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 0).addBox(-4, -8, -4, 8, 8, 8), PartPose.ZERO);
        r.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 16).addBox(-3, 0, -2, 6, 12, 4), PartPose.ZERO);
        CubeListBuilder armR = CubeListBuilder.create().texOffs(32, 16).addBox(-2, 0, -1, 2, 14, 2);
        CubeListBuilder armL = CubeListBuilder.create().texOffs(32, 16).mirror().addBox(0, 0, -1, 2, 14, 2);
        r.addOrReplaceChild("right_arm", armR, PartPose.offset(-3, 1, 0));
        r.addOrReplaceChild("left_arm", armL, PartPose.offset(3, 1, 0));
        r.addOrReplaceChild("right_arm2", armR, PartPose.offset(-3, 3, 0));
        r.addOrReplaceChild("left_arm2", armL, PartPose.offset(3, 3, 0));
        r.addOrReplaceChild("right_arm3", armR, PartPose.offset(-3, 5, 0));
        r.addOrReplaceChild("left_arm3", armL, PartPose.offset(3, 5, 0));
        r.addOrReplaceChild("right_leg", CubeListBuilder.create().texOffs(40, 16).addBox(-1, 0, -1, 2, 12, 2), PartPose.offset(-1.5f, 12, 0));
        r.addOrReplaceChild("left_leg", CubeListBuilder.create().texOffs(40, 16).mirror().addBox(-1, 0, -1, 2, 12, 2), PartPose.offset(1.5f, 12, 0));
        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override public ModelPart root() { return root; }

    @Override
    public void setupAnim(DreamCreature e, float limbSwing, float limbSwingAmount, float age, float headYaw, float headPitch) {
        root.getAllParts().forEach(ModelPart::resetPose);
        float id = e.getId();

        // --- Animación "dreamcore": balanceo lento + glitch ocasional de cabeza ---
        float sway = Mth.sin(age * 0.05f + id) * 0.06f;
        float glitch = (((int) age + (int) id) % 70 < 3) ? Mth.sin(age * 7f) * 0.5f : 0f;

        head.yRot = headYaw * Mth.DEG_TO_RAD + glitch * 0.5f;
        head.xRot = headPitch * Mth.DEG_TO_RAD;
        head.zRot = sway * 1.5f + glitch;
        body.zRot = sway;

        float swing = limbSwing * 0.6662f;
        rLeg.xRot = Mth.cos(swing) * 1.2f * limbSwingAmount;
        lLeg.xRot = Mth.cos(swing + Mth.PI) * 1.2f * limbSwingAmount;

        animateArm(rArm, swing + Mth.PI, limbSwingAmount, age, id, -1);
        animateArm(lArm, swing, limbSwingAmount, age, id + 1, 1);

        boolean extra = e.getVariant().extraArms;
        rArm2.visible = lArm2.visible = rArm3.visible = lArm3.visible = extra;
        if (extra) {
            animateArm(rArm2, swing + 1.0f, limbSwingAmount, age, id + 2, -1);
            animateArm(lArm2, swing + 2.0f, limbSwingAmount, age, id + 3, 1);
            animateArm(rArm3, swing + 3.0f, limbSwingAmount, age, id + 4, -1);
            animateArm(lArm3, swing + 4.0f, limbSwingAmount, age, id + 5, 1);
        }
    }

    private static void animateArm(ModelPart arm, float swing, float amount, float age, float phase, int side) {
        arm.xRot = Mth.cos(swing) * 1.2f * amount + Mth.sin(age * 0.04f + phase) * 0.08f;
        arm.zRot = side * (0.05f + Mth.cos(age * 0.09f + phase) * 0.05f);
    }
}
