package com.nowheredreams.client;

import com.nowheredreams.ModDimensions;
import com.nowheredreams.NowhereDreams;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.FogRenderer;
import net.minecraft.util.Mth;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ViewportEvent;
import com.mojang.blaze3d.shaders.FogShape;
import net.minecraft.resources.ResourceKey;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Efectos visuales: niebla de color cambiante, FOV que respira y cámara ligeramente inclinada. */
@Mod.EventBusSubscriber(modid = NowhereDreams.MODID, value = Dist.CLIENT)
public class DreamClientEvents {

    private static ResourceKey<Level> dim() {
        Minecraft mc = Minecraft.getInstance();
        return mc.level == null ? null : mc.level.dimension();
    }

    private static boolean inDream() {
        ResourceKey<Level> d = dim();
        return d != null && ModDimensions.isDream(d);
    }

    private static float time(double partial) {
        return (Minecraft.getInstance().level.getGameTime() + (float) partial) * 0.01f;
    }

    @SubscribeEvent
    public static void fogColor(ViewportEvent.ComputeFogColor e) {
        if (!inDream()) return;
        float t = time(e.getPartialTick());
        ResourceKey<Level> d = dim();
        if (d == ModDimensions.BETA) { // azul-gris de la niebla de Beta
            e.setRed(0.73f); e.setGreen(0.83f); e.setBlue(1.0f);
        } else if (d == ModDimensions.VOID) { // violeta que respira
            e.setRed(Mth.clamp(0.45f + 0.15f * Mth.sin(t), 0, 1));
            e.setGreen(Mth.clamp(0.25f + 0.10f * Mth.sin(t + 2.1f), 0, 1));
            e.setBlue(Mth.clamp(0.70f + 0.15f * Mth.sin(t + 4.2f), 0, 1));
        } else { // rosa/amarillo pastel que cambia
            e.setRed(Mth.clamp(0.90f + 0.08f * Mth.sin(t), 0, 1));
            e.setGreen(Mth.clamp(0.65f + 0.15f * Mth.sin(t + 2.1f), 0, 1));
            e.setBlue(Mth.clamp(0.80f + 0.12f * Mth.sin(t + 4.2f), 0, 1));
        }
    }

    /** Niebla corta estilo Beta. */
    @SubscribeEvent
    public static void fog(ViewportEvent.RenderFog e) {
        if (!inDream() || e.getMode() != FogRenderer.FogMode.FOG_TERRAIN) return;
        ResourceKey<Level> d = dim();
        float far = d == ModDimensions.LIMINAL ? 48f : d == ModDimensions.VOID ? 80f : 112f;
        e.setNearPlaneDistance(far * 0.1f);
        e.setFarPlaneDistance(far);
        e.setFogShape(FogShape.SPHERE);
        e.setCanceled(true);
    }

    @SubscribeEvent
    public static void fov(ViewportEvent.ComputeFov e) {
        if (!inDream()) return;
        e.setFOV(e.getFOV() + Mth.sin(time(e.getPartialTick()) * 3f) * 2.5);
    }

    @SubscribeEvent
    public static void roll(ViewportEvent.ComputeCameraAngles e) {
        if (!inDream()) return;
        e.setRoll(e.getRoll() + Mth.sin(time(e.getPartialTick()) * 1.7f) * 1.2f);
    }
}
