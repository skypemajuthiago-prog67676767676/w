package com.nowheredreams;

import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.Heightmap;

public final class ModDimensions {
    public static final ResourceKey<Level> LIMINAL = key("liminal_halls");
    public static final ResourceKey<Level> VOID = key("dream_void");
    public static final ResourceKey<Level> BETA = key("beta_lands");

    private static final List<ResourceKey<Level>> CYCLE = List.of(Level.OVERWORLD, LIMINAL, VOID, BETA);

    private static ResourceKey<Level> key(String name) {
        return ResourceKey.create(Registries.DIMENSION, new ResourceLocation(NowhereDreams.MODID, name));
    }

    public static boolean isDream(ResourceKey<Level> k) {
        return k.location().getNamespace().equals(NowhereDreams.MODID);
    }

    /** Overworld -> Liminal -> Void -> Beta -> Overworld. Cualquier otra dimensión vuelve al inicio del ciclo. */
    public static ResourceKey<Level> nextAfter(ResourceKey<Level> current) {
        int i = CYCLE.indexOf(current);
        return CYCLE.get((i + 1) % CYCLE.size());
    }

    public static void travel(ServerPlayer p, ResourceKey<Level> target) {
        ServerLevel dest = p.server.getLevel(target);
        if (dest == null) return;
        BlockPos base = target == Level.OVERWORLD ? dest.getSharedSpawnPos() : BlockPos.ZERO;
        int x = base.getX(), z = base.getZ();
        dest.getChunk(x >> 4, z >> 4); // fuerza la carga del chunk
        int y = dest.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
        if (y <= dest.getMinBuildHeight() + 1) { // vacío: crea una plataforma
            y = 64;
            for (int dx = -2; dx <= 2; dx++)
                for (int dz = -2; dz <= 2; dz++)
                    dest.setBlockAndUpdate(new BlockPos(x + dx, y - 1, z + dz), Blocks.WHITE_CONCRETE.defaultBlockState());
        }
        p.teleportTo(dest, x + 0.5, y, z + 0.5, p.getYRot(), p.getXRot());
    }

    private ModDimensions() {}
}
