package com.nowheredreams;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

public class DreamCreature extends Monster {
    private final CreatureVariant variant;

    public DreamCreature(EntityType<? extends DreamCreature> type, Level level, CreatureVariant variant) {
        super(type, level);
        this.variant = variant;
        this.xpReward = 10;
    }

    public CreatureVariant getVariant() { return variant; }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.0D, false));
        goalSelector.addGoal(2, new WaterAvoidingRandomStrollGoal(this, 0.6D));
        goalSelector.addGoal(3, new LookAtPlayerGoal(this, Player.class, 24.0F));
        goalSelector.addGoal(4, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    public static AttributeSupplier.Builder createAttributes(CreatureVariant v) {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, v.health)
                .add(Attributes.ATTACK_DAMAGE, v.damage)
                .add(Attributes.MOVEMENT_SPEED, v.speed)
                .add(Attributes.FOLLOW_RANGE, 48.0D);
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        boolean hit = super.doHurtTarget(target);
        if (hit && target instanceof LivingEntity living && variant.effect != null) {
            living.addEffect(new MobEffectInstance(variant.effect.get(), variant.effectSeconds * 20));
        }
        return hit;
    }

    @Override protected SoundEvent getAmbientSound() { return SoundEvents.AMBIENT_CAVE.value(); }
    @Override public int getAmbientSoundInterval() { return 400; }
}
